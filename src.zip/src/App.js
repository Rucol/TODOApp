
import './App.css';
import { TodoWrapper } from './components/TodoWrapper';
import Clock from './components/Clock'

function App() {
  return (
    <div className="App">
      <Clock />
      <TodoWrapper/>
    </div>
  );
}

export default App;
