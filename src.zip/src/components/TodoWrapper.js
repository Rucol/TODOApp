import React, { useState, useEffect } from "react";
import { Todo } from "./Todo";
import { TodoForm } from "./TodoForm";
import { v4 as uuidv4 } from "uuid";
import { EditTodoForm } from "./EditTodoForm";
import { CButton } from "@coreui/react"; // Importowanie komponentu przycisku Core UI
import { Button } from "react-bootstrap"; // Importowanie komponentu przycisku z React Bootstrap

export const TodoWrapper = () => {
  const [todos, setTodos] = useState([]);
  const [weeklyTodos, setWeeklyTodos] = useState([]);

  useEffect(() => {
    const dailyInterval = setInterval(() => {
      setTodos((prevTodos) =>
        prevTodos.map((todo) => {
          if (!todo.completed && todo.deadline) {
            const updatedDeadline = todo.deadline - 1000;
            if (updatedDeadline <= 0) {
              return { ...todo, completed: true };
            } else {
              return { ...todo, deadline: updatedDeadline };
            }
          } else {
            return todo;
          }
        })
      );
    }, 1000);

    return () => {
      clearInterval(dailyInterval);
    };
  }, []);

  const addTodo = (todo) => {
    setTodos([
      ...todos,
      {
        id: uuidv4(),
        task: todo,
        completed: false,
        isEditing: false,
        deadline: Date.now() + 86400000,
      },
    ]);
  };

  const addWeeklyTodo = (todo) => {
    setWeeklyTodos([
      ...weeklyTodos,
      {
        id: uuidv4(),
        task: todo,
        completed: false,
        deadline: Date.now() + 7 * 86400000,
      },
    ]);
  };

  const deleteTodo = (id) => setTodos(todos.filter((todo) => todo.id !== id));

  const deleteWeeklyTodo = (id) =>
    setWeeklyTodos(weeklyTodos.filter((todo) => todo.id !== id));

  const toggleComplete = (id, listType) => {
    if (listType === "daily") {
      setTodos((prevTodos) =>
        prevTodos.map((todo) =>
          todo.id === id
            ? todo.deadline && todo.deadline < Date.now()
              ? { ...todo, completed: false, deadline: Date.now() + 60000 }
              : { ...todo, completed: !todo.completed }
            : todo
        )
      );
    } else if (listType === "weekly") {
      setWeeklyTodos((prevWeeklyTodos) =>
        prevWeeklyTodos.map((todo) =>
          todo.id === id
            ? todo.deadline && todo.deadline < Date.now()
              ? { ...todo, completed: false, deadline: Date.now() + 7 * 86400000 }
              : { ...todo, completed: !todo.completed }
            : todo
        )
      );
    }
  };

  const editTodo = (id, listType) => {
    if (listType === "daily") {
      setTodos(
        todos.map((todo) =>
          todo.id === id ? { ...todo, isEditing: !todo.isEditing } : todo
        )
      );
    } else if (listType === "weekly") {
      setWeeklyTodos(
        weeklyTodos.map((todo) =>
          todo.id === id ? { ...todo, isEditing: !todo.isEditing } : todo
        )
      );
    }
  };

  const editTask = (task, id, listType) => {
    if (listType === "daily") {
      setTodos(
        todos.map((todo) =>
          todo.id === id ? { ...todo, task, isEditing: !todo.isEditing } : todo
        )
      );
    } else if (listType === "weekly") {
      setWeeklyTodos(
        weeklyTodos.map((todo) =>
          todo.id === id ? { ...todo, task, isEditing: !todo.isEditing } : todo
        )
      );
    }
  };

  const plugWeekly = (task) => {
    setWeeklyTodos([
      ...weeklyTodos,
      { id: uuidv4(), task, completed: false, deadline: null },
    ]);
  };

  return (
    <div className="TodoWrapper">
      <h1>Get Things Done !</h1>
      <h3>Click plug to plug task as a weekly!</h3>
      <TodoForm addTodo={addTodo} />
      <h3>Daily Todos:</h3>
      {todos.map((todo) =>
        todo.isEditing ? (
          <EditTodoForm
            key={todo.id}
            editTodo={(task, id) => editTask(task, id, "daily")}
            task={todo}
          />
        ) : (
          <Todo
            key={todo.id}
            task={todo}
            deleteTodo={deleteTodo}
            editTodo={(id) => editTodo(id, "daily")}
            toggleComplete={(id) => toggleComplete(id, "daily")}
            plugWeekly={plugWeekly}
          />
        )
      )}
      <h3>Weekly Todos:</h3>
      {weeklyTodos.map((todo) =>
        todo.isEditing ? (
          <EditTodoForm
            key={todo.id}
            editTodo={(task, id) => editTask(task, id, "weekly")}
            task={todo}
          />
        ) : (
          <Todo
            key={todo.id}
            task={todo}
            deleteTodo={deleteWeeklyTodo}
            editTodo={(id) => editTodo(id, "weekly")}
            toggleComplete={(id) => toggleComplete(id, "weekly")}
          />
        )
      )}
      {/* Użyj przycisku React Bootstrap do dodawania dziennego zadania */}
      <Button variant="primary" onClick={() => addTodo("Daily Task")}>
        Add Daily Todo
      </Button>
      {/* Użyj przycisku Core UI do dodawania tygodniowego zadania */}
      <CButton color="primary" onClick={() => addWeeklyTodo("Weekly Task")}>
        Add Weekly Todo
      </CButton>
    </div>
  );
};
